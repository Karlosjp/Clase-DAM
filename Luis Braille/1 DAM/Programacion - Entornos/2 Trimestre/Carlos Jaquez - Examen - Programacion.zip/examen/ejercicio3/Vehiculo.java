package examen.ejercicio3;

public abstract class Vehiculo {
	public abstract double impuesto();
}
