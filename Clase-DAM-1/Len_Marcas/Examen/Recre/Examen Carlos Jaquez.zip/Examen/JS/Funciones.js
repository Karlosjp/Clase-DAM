function puntuacion(ficha) {
	var p = document.getElementById("total2");
	var puntos;
	if (ficha == 3) {
		puntos = parseInt(p.innerHTML);
		puntos = 1000;

		p.innerHTML = puntos;
	}

	if (ficha == 2) {
		puntos = parseInt(p.innerHTML);
		puntos = 500;
		p.innerHTML = puntos;
	}

	if(ficha < 2){
		puntos = parseInt(p.innerHTML);
		puntos = 0;
		p.innerHTML = puntos;
	}
}

function recuento() {
	var p = document.getElementsByTagName('img');
	var fresa = 0;
	var limon = 0;
	var sandia = 0;
	var puntos = 0;

	for (var i = 0; i < p.length; i++) {
		if(p[i].id == "Fresa"){
			fresa ++;
		}
		if(p[i].id == "Limon"){
			limon ++;
		}
		if(p[i].id == "Sandia"){
			sandia ++;
		}
	}

	if (fresa > 1) {
		puntos = fresa;
	} 
	if (puntos < limon) {
		puntos = limon;
	} 
	if (puntos < sandia) {
		puntos = sandia;
	}
	puntuacion(puntos);
}

function aleatorio(num) {
	var p = Math.floor((Math.random()*3)+1);
	var imagen = document.getElementsByTagName('img');

	if(p==1){
		imagen[num].src = "Imagenes/Fresa.png";
		imagen[num].id = "Fresa";
		recuento();
	} 

	if(p==2){
		imagen[num].src = "Imagenes/Limon.png";
		imagen[num].id = "Limon";
		recuento();
	} 
		if (p==3) {
		imagen[num].src = "Imagenes/Sandia.png";
		imagen[num].id = "Sandia";
		recuento();
	}
}

function reiniciar(total){
	var p

	for (var i = 1; i < 3; i++) {
		p = document.getElementById(total+i);
		p.innerHTML = 0;
	}
}

function guardar() {
	var p = document.getElementById("total2");
	var puntos = parseInt(p.innerHTML);
	p = document.getElementById("total1");
	puntos += parseInt(p.innerHTML);
	p.innerHTML = puntos;
}